# Movie Catalogue App

*Submission for Dicoding Android Development Learning Path - "Belajar Android Jetpack Pro"*

## Requirements

* Android Studio
* Git
* Android build tools v 28+
* An Android phone 7.0 and up

## Common setup

Clone the repo and install the dependencies.

```bash
git clone https://github.com/nugrahaa878/MovieCatalogueApp.git
```

## Maintainers
This project is mantained by:
* [Ari Angga Nugraha](http://github.com/nugrahaa878)